import { GoogleGenAI } from "@google/genai";

async function generateAnkoImage() {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          text: 'A cinematic and ethereal representation of the poem "Plum Blossoms in a Mountain Garden". A single, elegant branch of white plum blossoms in full bloom, illuminated by a faint, hazy moon in a deep twilight sky. The atmosphere is quiet, serene, and detached from the world. Velvety black shadows contrast with the pale, glowing petals. A sense of "hidden fragrance floating in the air" (Anko Fudo). Minimalist Japanese aesthetic, high contrast, sharp focus on the blossoms, moody and profound beauty (Yugen). 16:9 aspect ratio.',
        },
      ],
    },
    config: {
      imageConfig: {
        aspectRatio: "16:9",
      },
    },
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      console.log(part.inlineData.data);
    }
  }
}

generateAnkoImage();
